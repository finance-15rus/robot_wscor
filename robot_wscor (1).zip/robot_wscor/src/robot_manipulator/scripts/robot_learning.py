#!/usr/bin/env python3
import rospy
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from geometry_msgs.msg import Pose
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64
import pickle
import os
from datetime import datetime

class RobotStateEncoder(nn.Module):
    def __init__(self, input_dim=12, hidden_dim=64, latent_dim=32):
        super(RobotStateEncoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, latent_dim)
        )
        
    def forward(self, x):
        return self.encoder(x)

class RobotController:
    def __init__(self):
        # Инициализация ROS ноды
        rospy.init_node('robot_learning_controller')
        
        # Параметры обучения
        self.learning_rate = 0.001
        self.batch_size = 32
        self.training_data = []
        self.model = RobotStateEncoder()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.learning_rate)
        
        # Параметры робота
        self.joint_positions = np.zeros(6)
        self.joint_velocities = np.zeros(6)
        self.end_effector_pose = None
        
        # Publishers для управления суставами
        self.joint_publishers = []
        for i in range(6):
            pub = rospy.Publisher(
                f'/industrial_manipulator/joint{i+1}_position_controller/command',
                Float64,
                queue_size=10
            )
            self.joint_publishers.append(pub)
        
        # Subscribers
        rospy.Subscriber('/industrial_manipulator/joint_states', 
                        JointState, 
                        self.joint_state_callback)
        
        # Путь для сохранения обученной модели
        self.model_path = os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            'trained_models'
        )
        if not os.path.exists(self.model_path):
            os.makedirs(self.model_path)
            
    def joint_state_callback(self, msg):
        """Обработка данных о состоянии суставов"""
        self.joint_positions = np.array(msg.position)
        self.joint_velocities = np.array(msg.velocity)
        
    def collect_training_data(self, duration=600):
        """Сбор обучающих данных в течение заданного времени"""
        rate = rospy.Rate(10)  # 10 Hz
        start_time = rospy.Time.now()
        
        while (rospy.Time.now() - start_time).to_sec() < duration:
            state = self.get_robot_state()
            self.training_data.append(state)
            rate.sleep()
            
        print(f"Collected {len(self.training_data)} training samples")
        
    def get_robot_state(self):
        """Получение текущего состояния робота"""
        return np.concatenate([
            self.joint_positions,
            self.joint_velocities
        ])
        
    def train_model(self, epochs=100):
        """Обучение модели на собранных данных"""
        if len(self.training_data) < self.batch_size:
            print("Not enough training data")
            return
            
        print("Starting model training...")
        training_data = torch.FloatTensor(self.training_data)
        
        for epoch in range(epochs):
            total_loss = 0
            # Перемешивание данных
            indices = torch.randperm(len(training_data))
            
            for i in range(0, len(training_data), self.batch_size):
                batch_indices = indices[i:i + self.batch_size]
                batch = training_data[batch_indices]
                
                # Прямой проход
                encoded = self.model(batch)
                decoded = self.model.encoder(encoded)
                
                # Вычисление потерь
                loss = F.mse_loss(decoded, batch)
                
                # Обратное распространение
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                
                total_loss += loss.item()
                
            avg_loss = total_loss / (len(training_data) / self.batch_size)
            if (epoch + 1) % 10 == 0:
                print(f"Epoch [{epoch+1}/{epochs}], Loss: {avg_loss:.4f}")
                
        self.save_model()
        
    def save_model(self):
        """Сохранение обученной модели"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        model_file = os.path.join(self.model_path, f'robot_model_{timestamp}.pt')
        
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'training_data': self.training_data
        }, model_file)
        
        print(f"Model saved to {model_file}")
        
    def load_model(self, model_file):
        """Загрузка обученной модели"""
        if not os.path.exists(model_file):
            print(f"Model file {model_file} not found")
            return False
            
        checkpoint = torch.load(model_file)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.training_data = checkpoint['training_data']
        
        print(f"Model loaded from {model_file}")
        return True
        
    def execute_learned_trajectory(self, target_pose):
        """Выполнение траектории на основе обученной модели"""
        if not self.model:
            print("No trained model available")
            return False
            
        # Получение текущего состояния
        current_state = torch.FloatTensor(self.get_robot_state())
        
        # Кодирование состояния
        with torch.no_grad():
            encoded_state = self.model(current_state)
            
        # Генерация управляющих сигналов
        target_positions = self.generate_joint_positions(encoded_state, target_pose)
        
        # Отправка команд роботу
        for i, position in enumerate(target_positions):
            self.joint_publishers[i].publish(Float64(position))
            
        return True
        
    def generate_joint_positions(self, encoded_state, target_pose):
        """Генерация позиций суставов для достижения целевой позы"""
        decoded_state = self.model.encoder(encoded_state).numpy()
        joint_positions = decoded_state[:6]  # Берем только позиции суставов
        
        return joint_positions

def main():
    try:
        controller = RobotController()
        rospy.sleep(1)  # Ждем инициализации всех компонентов
        
        # Сбор обучающих данных
        print("Starting data collection...")
        controller.collect_training_data(duration=600)  # 10-30 минут сбора данных
        
        # Обучение модели
        print("Starting model training...")
        controller.train_model(epochs=100)
        
        # Тестирование обученной модели
        test_pose = Pose()  # Создаем тестовую позу
        test_pose.position.x = 0.5
        test_pose.position.y = 0.3
        test_pose.position.z = 0.7
        
        print("Executing learned trajectory...")
        controller.execute_learned_trajectory(test_pose)
        
        rospy.spin()
        
    except rospy.ROSInterruptException:
        pass

if __name__ == '__main__':
    main()